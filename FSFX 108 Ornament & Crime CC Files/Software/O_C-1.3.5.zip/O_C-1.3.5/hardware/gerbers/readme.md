CAM files for teensy 3.x quad 16 bit CV generator/processor
============

###gerbers for:

- O_C main pcb (2.e)
- SSD1306 / SH1106 OLED carrier pcb (thanks, altitude909)


###BOM for OLED carrier pcb

(all 0603): 

- 4 x 10k 
- 1 x 390K 
- 5 x 2.2uF (10V)
- 1 x 10uF (10V) 





